<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    
    <title>Evelope Report</title>
    
    <link rel="stylesheet" href="style.css" type="text/css" />
    
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
    <script type="text/javascript" src="chat.js"></script>
    <script type="text/javascript">
    
        // ask user for name with popup prompt    
        if (localStorage.getItem("codeName")) {
           name = localStorage.getItem("codeName")
        } else {
           var name = prompt("Enter your username for this game:", "Guest");
           localStorage.setItem("codeName", name)
           
           // default name is 'Guest'
    	   if (!name || name === ' ') {
    	      name = "Guest";	
           }
    	}
    	// strip tags
    	name = name.replace(/(<([^>]+)>)/ig,"");
    	
    	// display name on page
    	$("#name-area").html("You are: <span>" + name + "</span>");
    	
    	// kick off chat
        var chat =  new Chat();
    	$(function() {
    	
    		 chat.getState(); 
    		 
    		 // watch textarea for release of key press
    		 $('#sendie').click(function() {	
    		 					 
    			  //if (orderSendActivation == 1) { 
    			 
    			// function SendOrd() {
                    var text = $(this).val();
    				var maxLength = $(this).attr("maxlength");  
                    var length = text.length; 
                     
                    // send 
                    if (length <= maxLength + 1) { 
                     
    			        chat.send(text, name);	
    			        $(this).val("");
    			        
                    } else {
                    
    					$(this).val(text.substring(0, maxLength));
    					
    				}	
    				
    			//}
    				
    			  //}
             });
            
    	});
    </script>

</head>

<body onload="setInterval('chat.update()', 1000)">

    <div id="page-wrap">
        
        <p id="name-area"></p>
        
        <form id="send-message-area">
         <table>
          <tr>
           <td>
            <p>How many envelopes did you hide?<br>Type a number and press enter</p>
           </td>
          </tr>
          <tr>
           <td>
            <input type="number" id="envelopeCount" min="1" max="999" onclick="repeater()" onkeypress="repeater()"><input type="button" onclick="document.getElementById('sendie').click();" value="Send">
            <textarea id="sendie" maxlength = '999' style="opacity:0.9; position:absoulte; top:0%; left:0%; width:10.25%; height:10.25%;"></textarea>
           </td>
          </tr>
         </table>
        </form>
    
    </div>

<script>
function repeater() {
     var repNum = document.getElementById('envelopeCount').value
     document.getElementById('sendie').value = repNum;
}
</script>

</body>

</html>