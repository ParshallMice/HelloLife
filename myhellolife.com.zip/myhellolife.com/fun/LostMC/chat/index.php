<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    
    <title>Chat</title>
    
    <link rel="stylesheet" href="style.css" type="text/css" />
    
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
    <script type="text/javascript" src="chat.js"></script>
    <script type="text/javascript">
        
        
        // ask user for name with popup prompt    
        if (localStorage.getItem("LostMCName")) {
           name = localStorage.getItem("LostMCName")
        } else {
           var name = prompt("Enter your username for this game:", "Guest");
           localStorage.setItem("LostMCName", name)
           
           // default name is 'Guest'
    	   if (!name || name === ' ') {
    	      name = "Guest";	
           }
    	}
    	
    	// strip tags
    	name = name.replace(/(<([^>]+)>)/ig,"");
    	
    	// display name on page
    	$("#name-area").html("You are: <span>" + name + "</span>");
    	
    	// kick off chat
        var chat =  new Chat();
    	$(function() {
    	
    		 chat.getState(); 
    		 
    		 // watch textarea for key presses
             $("#sendie").keydown(function(event) {  
             
                 var key = event.which;  
           
                 //all keys including return.  
                 if (key >= 33) {
                   
                     var maxLength = $(this).attr("maxlength");  
                     var length = this.value.length;  
                     
                     // don't allow new content if length is maxed out
                     if (length >= maxLength) {  
                         event.preventDefault();  
                     }  
                  }  
    		 																																																});
    		 // watch textarea for release of key press
    		 $('#sendie').keyup(function(e) {	
    		 					 
    			  if (e.keyCode == 13) { 
    			  
                    var text = $(this).val();
    				var maxLength = $(this).attr("maxlength");  
                    var length = text.length; 
                     
                    // send 
                    if (length <= maxLength + 1) { 
                     
    			        chat.send(text, name);	
    			        $(this).val("");
    			        
                    } else {
                    
    					$(this).val(text.substring(0, maxLength));
    					
    				}	
    				
    				
    			  }
             });
            
    	});
    </script>

</head>

<body onload="document.getElementById('User-Name').innerHTML = localStorage.LostMCName + ': '; repEmoji(); chat.send(name + ' just joined the chat room.', 'LostMC'); setInterval('chat.update()', 1000);">

    <div id="page-wrap" style="left:1%; top:3%; width: 50%; height: 94%;">
    
        <h2>LostMC</h2>
        
        <p id="name-area"></p>
        
        <div id="chat-wrap" style="left:1%; top:1%; width: 98%; height: 88%;"><div id="chat-area"></div></div>
        
        <form id="send-message-area" style="bottom:20%; width:98%; right:1%; height:10%">
            <p id="User-Name" style="left:1%; bottom:1%; width:9%">You: </p>
            <textarea type="text" id="sendie" style="right:5%; bottom:1%; width:85%;" maxlength = '100' onload="setTimeout('this.focus();', 1000"></textarea>


<div class="dropdown" style="position:absolute; bottom:2%; right:2%">
<div onclick="drpdwnfunc()" class="dropbtn" style="font-size: 30px;">&#128512</div>
  <div id="myDropdown" class="dropdown-content">
  <table style="position:absolute; bottom:100%; right:-10%">
   <tr>
    <td><a onclick="addEmoji(':D')">&#128512</a></td>
    <td><a onclick="addEmoji(':\')')">&#128514</a></td>
    <td><a onclick="addEmoji(':)')">&#128522</a></td>
   </tr>
   <tr>
    <td><a onclick="addEmoji(':)')">&#128523</a></td>
    <td><a onclick="addEmoji(':)')">&#128518</a></td>
    <td><a onclick="addEmoji(':)')">&#128521</a></td>
   </tr>
   <tr>
    <td><a onclick="addEmoji(':)')">&#128515</a></td>
    <td><a onclick="addEmoji(':|')">&#128528</a></td>
    <td><a onclick="addEmoji(':o')">&#128558</a></td>
   </tr>
   <tr>
    <!--td><a onclick="addEmoji(':)')">&#1285XX</a></td>
    <td><a onclick="addEmoji(':)')">&#1285XX</a></td-->
    <td><a onclick="addEmoji(':/')">&#128533</a></td>
   </tr>
   <tr>
    <td><a onclick="addEmoji(';P')">&#128540</a></td>
    <td><a onclick="addEmoji('[s]')"><img src='http://i.imgur.com/Eu2dBQp.png' height='20px'></a></td>
    <td><a onclick="addEmoji('[g]')"><img src='http://i.imgur.com/S9G0zal.png' height='20px'></a></td>
   </tr>
  </table>
  </div>
</div>

        </form>
    
    </div>
    
<script>
function repEmoji() {
    var str = document.getElementById("chat-area").innerHTML; 
    var res = str.replace("[s]", "<img src='img/dsword.png' height='20px'>");
    var res = res.replace("[g]", "<img src='img/grass.png' height='20px'>");
    var res = res.replace("[l]", "<img src='img/lost.png' height='20px'>");
    var res = res.replace(":D", "&#128512");
    var res = res.replace(":')", "&#128514");
    var res = res.replace(":)", "&#128522");
    
    var res = res.replace(":P", "&#128523");
    var res = res.replace("XD", "&#128518");
    var res = res.replace("xD", "&#128518");
    
    var res = res.replace(";)", "&#128521");
    var res = res.replace("=)", "&#128515");
    var res = res.replace(":|", "&#128528");
    
    var res = res.replace(":o", "&#128558");
    var res = res.replace(";P", "&#128540");
    var res = res.replace(":/", "&#128533");
    var res = res.replace("b{", "<b>");
    var res = res.replace("}b", "</b>");
    var res = res.replace("i{", "<i>");
    var res = res.replace("}i", "</i>");
    var res = res.replace("u{", "<u>");
    var res = res.replace("}u", "</u>");
    var res = res.replace("fuck", "****");
//    var res = res.replace("oooo", "&#128561");
//    var res = res.replace(":)", "&#1285XX");
    document.getElementById("chat-area").innerHTML = res;
    if (str.indexOf("[forceReload]") >= 0) {
       location.reload();
    } else if (str.indexOf("[crash]") >= 0) {
       window.close();
    } else {
       setTimeout(repEmoji, 500)
    }
}
var cword, i;
var fcword = "fuck"
//cleanUp()
function cleanUp() {
    var text = document.getElementById("chat-area").innerHTML;
    for (i = 0; i >= fcword.lenght; i++) {
       cword = fcword[i]
       var text = text.replace(cword, "****");
    }
    document.getElementById("chat-area").innerHTML = text;
    
    setTimeout(cleanUp, 500)
}

function drpdwnfunc() {
    document.getElementById("myDropdown").classList.toggle("show");
}

function addEmoji(text) {
     var stext = document.getElementById("sendie")
     stext.value = stext.value + text;
}
</script>

</body>

</html>