A Pen created at CodePen.io. You can find this one at http://codepen.io/ollieRogers/pen/lfeLc.

 A quick demo on how to control an HTML 5  video by scrolling. 

- Won't work on mobile