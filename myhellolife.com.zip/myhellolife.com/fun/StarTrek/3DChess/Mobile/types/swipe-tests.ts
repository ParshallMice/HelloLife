/// <reference path="swipe.d.ts" />

// Creation of element
var mySwipe = new Swipe(document.getElementById('slider'));
