function get_linklaters() {
	    var linklaters = new Array;
	    var linklaters_str = localStorage.getItem('linklater');
	    if (linklaters_str !== null) {
	        linklaters = JSON.parse(linklaters_str); 
	    }
	    return linklaters;
	}
	 
	function add() {
	    var task = document.getElementById('linklater').value;
	
	    var linklaters = get_linklaters();
	    linklaters.push(task);
	    localStorage.setItem('linklater', JSON.stringify(linklaters));
	 
	    show();
	 
	    return false;
	}
	 
	function remove() {
	    var id = this.getAttribute('id');
	    var linklaters = get_linklaters();
	    linklaters.splice(id, 1);
	    localStorage.setItem('linklater', JSON.stringify(linklaters));
	 
	    show();
	 
	    return false;
	}
	 
	function show() {
	    var linklaters = get_linklaters();
	 
	    var html = '<ul class="w3-ul w3-card-4" style="background-color: white; background: -webkit-linear-gradient(bottom, rgb(201, 201, 201) 0%, rgb(255, 255, 255) 100%); background: -o-linear-gradient(bottom, rgb(201, 201, 201) 0%, rgb(255, 255, 255) 100%); background: -ms-linear-gradient(bottom, rgb(201, 201, 201) 0%, rgb(255, 255, 255) 100%); background: -moz-linear-gradient(bottom, rgb(201, 201, 201) 0%, rgb(255, 255, 255) 100%); background: linear-gradient(to top, rgb(201, 201, 201) 0%, rgb(255, 255, 255) 100%);">';
	    for(var i=0; i<linklaters.length; i++) {
	        html += '<li class="w3-padding-16"><span class="w3-closebtn w3-margin-right w3-medium w3-hover-text-red removeLinkLater" id="' + i + '">&times;</span><span class="w3-large">' + linklaters[i] + '</span><br><span class="w3-large w3-hover-text-red">open and delete <span class="w3-large removeLinkLater" id="' + i + '">' + linklaters[i] + '</span></span></li>';
	    };
	    html += '</ul>';
	 
	    document.getElementById('linklaters').innerHTML = html;
	 
	    var buttons = document.getElementsByClassName('removeLinkLater');
	    for (var i=0; i < buttons.length; i++) {
	        buttons[i].addEventListener('click', remove);
	    };
	}
	/*
	n = task.search("\n")
	if (n > 1) {
	   show();
	}
	*/
	document.getElementById('addLinkLater').addEventListener('click', add);
	show();
	

function gatherResponces() {
     var name = document.getElementById("name").value
     var url = document.getElementById("url").value
     document.getElementById("linklater").value = "<a href=\"" + url + "\">" + name + "</a>";
}