// makes a multi dimentional array of the most common websites.
var commonXPhrases = [
    "porn",
    "xxx",
    "sex",
    "naked",
    "nude",
    "nsfw",
    "explicit",
    "erotic",
    "x-rated",
    "xrated",
    "x_rated",
    "rule_34",
    "rule34",
    "rule-34",
    "pron",
    "pr0n",
    "dirty",
    "skinflick",
    "skin_flick",
    "skin-flick",
    "fluffer",
    "smut",
    "redtube",
    "xnxx",
    "xvideos",
    "xhamster"
];

var linkBox;
var i

function TestForAdultURL() {
     linkBox = document.getElementById("link").value;
     for (i = 0; i <= commonXPhrases.length; i++) {
        if (linkBox.indexOf(commonXPhrases[i]) >= 0) {
           document.getElementById("link").value = "porn";
        }
     }
}